from fastapi import APIRouter, Depends, UploadFile, File
from typing import List
from models.schemas import (
    LoginRequest, TokenResponse, FileUploadResponse, 
    ChatRequest, ChatResponse, TaxSimulateRequest, TaxSimulateResponse,
    ChecklistResponse, ChecklistItem
)
from security.jwt_handler import verify_token
from services.auth_service import authenticate_employee, get_employee_profile
from services.payroll_service import get_payroll_data
from services.ocr_service import save_document, extract_payroll_data
from services.tax_service import simulate_tax
from services.ai_service import query_ai

router = APIRouter()

@router.post("/login", response_model=TokenResponse)
def login(req: LoginRequest):
    return authenticate_employee(req)

@router.get("/profile")
def get_profile(employee_id: str = Depends(verify_token)):
    return get_employee_profile(employee_id)

@router.post("/upload", response_model=FileUploadResponse)
def upload_payslip(file: UploadFile = File(...), employee_id: str = Depends(verify_token)):
    filename = save_document(file, employee_id)
    return {"filename": filename, "status": "success", "message": "File uploaded securely."}

@router.post("/extract")
def extract_data(filename: str, employee_id: str = Depends(verify_token)):
    return extract_payroll_data(filename, employee_id)

@router.get("/payroll")
def get_payroll(employee_id: str = Depends(verify_token)):
    return get_payroll_data(employee_id)

@router.post("/chat", response_model=ChatResponse)
def chat_with_ai(req: ChatRequest, employee_id: str = Depends(verify_token)):
    response = query_ai(req, employee_id)
    return {"response": response}

@router.post("/tax/simulate", response_model=TaxSimulateResponse)
def tax_simulate(req: TaxSimulateRequest, employee_id: str = Depends(verify_token)):
    return simulate_tax(req)

@router.get("/checklist", response_model=ChecklistResponse)
def get_checklist(employee_id: str = Depends(verify_token)):
    # Mocking investment checklist
    items = [
        ChecklistItem(name="PAN", status="Submitted"),
        ChecklistItem(name="80C Proof", status="Pending"),
        ChecklistItem(name="HRA Rent Receipt", status="Missing"),
        ChecklistItem(name="Medical Insurance", status="Submitted"),
        ChecklistItem(name="Education Loan", status="Missing"),
        ChecklistItem(name="Home Loan", status="Pending")
    ]
    return {"items": items}

from pydantic import BaseModel
from typing import Optional, List, Dict, Any

class LoginRequest(BaseModel):
    employee_id: str
    
class TokenResponse(BaseModel):
    access_token: str
    token_type: str

class FileUploadResponse(BaseModel):
    filename: str
    status: str
    message: str

class ChatRequest(BaseModel):
    prompt: str
    has_pdf: bool = False
    has_image: bool = False
    
class ChatResponse(BaseModel):
    response: str
    
class TaxSimulateRequest(BaseModel):
    additional_80c_investment: float
    current_taxable_income: float
    current_deductions: float
    
class TaxSimulateResponse(BaseModel):
    estimated_taxable_income: float
    estimated_tax_saved: float
    assumptions: List[str]

class ChecklistItem(BaseModel):
    name: str
    status: str # "Submitted", "Pending", "Missing"

class ChecklistResponse(BaseModel):
    items: List[ChecklistItem]

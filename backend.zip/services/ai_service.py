import os
import requests
from fastapi import HTTPException
from models.schemas import ChatRequest
from services.payroll_service import get_payroll_data
from services.auth_service import get_employee_profile

LLM_API_URL = os.getenv("LLM_API_URL", "https://temp-llm-api.com/query") 
LLM_API_TOKEN = os.getenv("LLM_API_TOKEN", "your_api_token_here")

def query_ai(req: ChatRequest, employee_id: str):
    profile = get_employee_profile(employee_id)
    payroll = get_payroll_data(employee_id)
    
    system_prompt = (
        "You are a Payroll and Tax Assistant.\n"
        "You MUST answer ONLY using:\n"
        "1. Uploaded payslip\n"
        "2. Structured payroll data\n"
        "3. User profile\n"
        "Never invent numbers.\n"
        "Never hallucinate tax rules.\n"
        "If data is unavailable, clearly say 'I cannot determine this from the available payroll records.'\n"
        "Always explain calculations.\n"
        "Mention which payroll fields were used."
    )
    
    context = f"Employee Profile: {profile}\nPayroll Data: {payroll}"
    
    combined_prompt = f"System Instructions:\n{system_prompt}\n\nContext:\n{context}\n\nUser Question:\n{req.prompt}"
    
    payload = {
        "prompt": combined_prompt
    }
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LLM_API_TOKEN}"
    }
    
    try:
        response = requests.post(LLM_API_URL, json=payload, headers=headers)
        response.raise_for_status()
        resp_json = response.json()
        
        # Try to extract the response text gracefully
        if isinstance(resp_json, dict):
            # Check common keys
            return resp_json.get("response", resp_json.get("text", resp_json.get("answer", str(resp_json))))
        return str(resp_json)
    except Exception as e:
        print(f"Error calling LLM API: {e}")
        return "I am currently unable to reach my AI brain. Please try again later."

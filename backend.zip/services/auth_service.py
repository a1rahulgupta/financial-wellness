import json
import os
from fastapi import HTTPException
from models.schemas import LoginRequest
from security.jwt_handler import create_access_token

DATA_DIR = os.path.join(os.path.dirname(__file__), "../data")

def authenticate_employee(req: LoginRequest):
    employees_file = os.path.join(DATA_DIR, "employees.json")
    if not os.path.exists(employees_file):
        raise HTTPException(status_code=500, detail="Database missing")
        
    with open(employees_file, "r") as f:
        employees = json.load(f)
        
    for emp in employees:
        if emp["id"] == req.employee_id:
            token = create_access_token({"sub": emp["id"]})
            return {"access_token": token, "token_type": "bearer"}
            
    raise HTTPException(status_code=401, detail="Invalid employee ID")
    
def get_employee_profile(employee_id: str):
    employees_file = os.path.join(DATA_DIR, "employees.json")
    with open(employees_file, "r") as f:
        employees = json.load(f)
    for emp in employees:
        if emp["id"] == employee_id:
            return emp
    return None

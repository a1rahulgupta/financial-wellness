import json
import os

DATA_DIR = os.path.join(os.path.dirname(__file__), "../data")

def get_payroll_data(employee_id: str):
    payroll_file = os.path.join(DATA_DIR, "payroll.json")
    if not os.path.exists(payroll_file):
        return None
        
    with open(payroll_file, "r") as f:
        payroll_db = json.load(f)
        
    return payroll_db.get(employee_id)

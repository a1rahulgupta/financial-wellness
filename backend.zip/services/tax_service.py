from models.schemas import TaxSimulateRequest

def simulate_tax(req: TaxSimulateRequest):
    # Extremely simplified mock tax logic
    new_taxable_income = req.current_taxable_income - req.additional_80c_investment
    if new_taxable_income < 0:
        new_taxable_income = 0
        
    # Assume 30% tax bracket for simplicity
    current_tax = req.current_taxable_income * 0.30
    new_tax = new_taxable_income * 0.30
    
    tax_saved = current_tax - new_tax
    
    return {
        "estimated_taxable_income": new_taxable_income,
        "estimated_tax_saved": tax_saved,
        "assumptions": [
            "Flat 30% tax rate applied to taxable income.",
            "Maximum 80C limit (1.5 Lakhs) is assumed to be handled by the user before input."
        ]
    }

import json
import os
import shutil
import base64
import requests
from fastapi import UploadFile

OCR_DIR = os.path.join(os.path.dirname(__file__), "../ocr")
DOC_DIR = os.path.join(os.path.dirname(__file__), "../documents")

LLM_API_URL = os.getenv("LLM_API_URL", "https://llm-wrapper-741152993481.asia-south1.run.app/llm/query")
LLM_API_TOKEN = os.getenv("LLM_API_TOKEN", "lw_p8bAulfhgfhgfhfhfhfghgfhgfhgfhgfhgfSASgl6HDS0bSw-nCRIXwNfkjtY")

def save_document(file: UploadFile, employee_id: str):
    emp_doc_dir = os.path.join(DOC_DIR, employee_id)
    os.makedirs(emp_doc_dir, exist_ok=True)
    file_path = os.path.join(emp_doc_dir, file.filename)
    
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
        
    return file.filename

def extract_payroll_data(filename: str, employee_id: str):
    file_path = os.path.join(DOC_DIR, employee_id, filename)
    
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File {filename} not found.")

    prompt = (
        "Extract the payroll information from this document. "
        "Return ONLY a valid JSON object with the following numeric keys: "
        "basic_salary, hra, lta, special_allowance, pf, professional_tax, income_tax, reimbursement, gross_pay, net_pay, ytd_gross, ytd_net. "
        "And string keys: month, year. "
        "Do not include any markdown formatting, just raw JSON."
    )
    
    payload = {"prompt": prompt}
    
    # Read file and encode to base64
    with open(file_path, "rb") as f:
        file_bytes = f.read()
        b64_data = base64.b64encode(file_bytes).decode('utf-8')
        
    ext = filename.lower().split('.')[-1]
    
    if ext == 'pdf':
        payload['pdfBase64'] = b64_data
    elif ext in ['png', 'jpg', 'jpeg', 'gif', 'webp']:
        payload['imageBase64'] = b64_data
        if ext == 'jpg': ext = 'jpeg'
        payload['imageMediaType'] = f"image/{ext}"
    else:
        # Fallback to mock if unsupported
        return _fallback_mock(employee_id)

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {LLM_API_TOKEN}"
    }

    try:
        response = requests.post(LLM_API_URL, json=payload, headers=headers)
        response.raise_for_status()
        resp_json = response.json()
        
        # Extract text response from LLM
        llm_text = resp_json.get("response", resp_json.get("text", resp_json.get("answer", "")))
        
        # Clean markdown formatting if present
        if "```json" in llm_text:
            llm_text = llm_text.split("```json")[1].split("```")[0].strip()
        elif "```" in llm_text:
            llm_text = llm_text.split("```")[1].split("```")[0].strip()
            
        data = json.loads(llm_text)
        data["employee_id"] = employee_id
        return data
        
    except Exception as e:
        print(f"OCR LLM API Error: {e}, falling back to mock.")
        return _fallback_mock(employee_id)

def _fallback_mock(employee_id: str):
    mock_file = os.path.join(OCR_DIR, "mock_ocr.json")
    with open(mock_file, "r") as f:
        data = json.load(f)
    data["employee_id"] = employee_id
    return data

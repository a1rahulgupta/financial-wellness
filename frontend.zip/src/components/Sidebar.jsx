import React from 'react';
import { Drawer, List, ListItem, ListItemIcon, ListItemText, Typography, Box, Divider } from '@mui/material';
import { 
  Dashboard, UploadFile, AccountBalanceWallet, 
  ChatBubble, Calculate, ChecklistRtl, Person 
} from '@mui/icons-material';
import { useLocation, useNavigate } from 'react-router-dom';

const drawerWidth = 240;

const menuItems = [
  { text: 'Dashboard', icon: <Dashboard />, path: '/' },
  { text: 'Upload Payslip', icon: <UploadFile />, path: '/upload' },
  { text: 'Payroll Records', icon: <AccountBalanceWallet />, path: '/payroll' },
  { text: 'AI Assistant', icon: <ChatBubble />, path: '/chat' },
  { text: 'Tax Simulator', icon: <Calculate />, path: '/tax' },
  { text: 'Proof Checklist', icon: <ChecklistRtl />, path: '/checklist' },
  { text: 'Profile', icon: <Person />, path: '/profile' },
];

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,
        '& .MuiDrawer-paper': {
          width: drawerWidth,
          boxSizing: 'border-box',
          bgcolor: 'background.paper',
          borderRight: '1px solid rgba(0, 0, 0, 0.08)'
        },
      }}
    >
      <Box sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 1.5 }}>
        <Box sx={{ width: 32, height: 32, borderRadius: 1, bgcolor: 'primary.main', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Typography variant="h6" fontWeight="bold" color="white" lineHeight={1}>F</Typography>
        </Box>
        <Typography variant="h6" fontWeight="bold" color="text.primary">
          FinAI
        </Typography>
      </Box>
      <Divider />
      <List sx={{ px: 2, py: 2 }}>
        {menuItems.map((item) => {
          const active = location.pathname === item.path;
          return (
            <ListItem 
              button 
              key={item.text} 
              onClick={() => navigate(item.path)}
              sx={{
                mb: 1,
                borderRadius: 2,
                bgcolor: active ? 'primary.light' : 'transparent',
                color: active ? 'primary.dark' : 'text.secondary',
                '&:hover': {
                  bgcolor: active ? 'primary.light' : 'action.hover',
                }
              }}
            >
              <ListItemIcon sx={{ color: 'inherit', minWidth: 40 }}>
                {item.icon}
              </ListItemIcon>
              <ListItemText 
                primary={item.text} 
                primaryTypographyProps={{ 
                  fontWeight: active ? 600 : 500,
                  fontSize: '0.9rem'
                }} 
              />
            </ListItem>
          );
        })}
      </List>
    </Drawer>
  );
}

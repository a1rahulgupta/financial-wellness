import React, { useState } from 'react';
import { Box, Paper, TextField, IconButton, Typography, CircularProgress } from '@mui/material';
import { ChatBubble, Close, Send } from '@mui/icons-material';
import { chatWithAi } from '../services/api';

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Hi! I am your AI Financial Assistant. Ask me anything about your payroll or taxes.' }
  ]);
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!prompt.trim()) return;
    
    const userMsg = prompt;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setPrompt('');
    setLoading(true);
    
    try {
      const res = await chatWithAi(userMsg);
      setMessages(prev => [...prev, { role: 'ai', text: res.response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Sorry, I am having trouble connecting to the server.' }]);
    } finally {
      setLoading(false);
    }
  };

  if (!open) {
    return (
      <IconButton 
        onClick={() => setOpen(true)}
        color="primary"
        sx={{
          position: 'fixed', bottom: 32, right: 32,
          bgcolor: 'primary.main', color: 'white',
          width: 64, height: 64,
          boxShadow: 3,
          '&:hover': { bgcolor: 'primary.dark' }
        }}
      >
        <ChatBubble fontSize="large" />
      </IconButton>
    );
  }

  return (
    <Paper 
      elevation={5} 
      sx={{ 
        position: 'fixed', bottom: 32, right: 32, 
        width: 350, height: 500, 
        display: 'flex', flexDirection: 'column',
        borderRadius: 3, overflow: 'hidden', zIndex: 1000
      }}
    >
      <Box sx={{ bgcolor: 'primary.main', color: 'white', p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Typography variant="h6">FinAI Assistant</Typography>
        <IconButton size="small" sx={{ color: 'white' }} onClick={() => setOpen(false)}>
          <Close />
        </IconButton>
      </Box>
      <Box sx={{ flexGrow: 1, p: 2, overflowY: 'auto', bgcolor: 'background.default', display: 'flex', flexDirection: 'column', gap: 1 }}>
        {messages.map((msg, i) => (
          <Box key={i} sx={{ alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '80%' }}>
            <Paper elevation={1} sx={{ p: 1.5, bgcolor: msg.role === 'user' ? 'primary.main' : 'white', color: msg.role === 'user' ? 'white' : 'text.primary', borderRadius: 2 }}>
              <Typography variant="body2">{msg.text}</Typography>
            </Paper>
          </Box>
        ))}
        {loading && <CircularProgress size={20} sx={{ alignSelf: 'center', mt: 1 }} />}
      </Box>
      <Box sx={{ p: 2, bgcolor: 'white', display: 'flex', gap: 1, borderTop: '1px solid rgba(0,0,0,0.1)' }}>
        <TextField 
          fullWidth size="small" placeholder="Ask a question..." 
          value={prompt} onChange={e => setPrompt(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && handleSend()}
        />
        <IconButton color="primary" onClick={handleSend} disabled={loading || !prompt.trim()}>
          <Send />
        </IconButton>
      </Box>
    </Paper>
  );
}

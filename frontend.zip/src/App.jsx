import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Box, CircularProgress } from '@mui/material';

// We will create these pages next
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Upload from './pages/Upload';
import Payroll from './pages/Payroll';
import Chat from './pages/Chat';
import TaxSimulator from './pages/TaxSimulator';
import Checklist from './pages/Checklist';
import Profile from './pages/Profile';
import Sidebar from './components/Sidebar';
import Topbar from './components/Topbar';

const ProtectedLayout = ({ children }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return <Box display="flex" justifyContent="center" alignItems="center" height="100vh"><CircularProgress /></Box>;
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }

  return (
    <Box sx={{ display: 'flex' }}>
      <Sidebar />
      <Box component="main" sx={{ flexGrow: 1, p: 3, width: { sm: `calc(100% - 240px)` } }}>
        <Topbar />
        <Box sx={{ mt: 8 }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
};

function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          
          <Route path="/" element={<ProtectedLayout><Dashboard /></ProtectedLayout>} />
          <Route path="/upload" element={<ProtectedLayout><Upload /></ProtectedLayout>} />
          <Route path="/payroll" element={<ProtectedLayout><Payroll /></ProtectedLayout>} />
          <Route path="/chat" element={<ProtectedLayout><Chat /></ProtectedLayout>} />
          <Route path="/tax" element={<ProtectedLayout><TaxSimulator /></ProtectedLayout>} />
          <Route path="/checklist" element={<ProtectedLayout><Checklist /></ProtectedLayout>} />
          <Route path="/profile" element={<ProtectedLayout><Profile /></ProtectedLayout>} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}

export default App;

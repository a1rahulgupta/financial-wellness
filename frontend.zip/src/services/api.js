import axios from 'axios';

const API_URL = '/api';

const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const login = async (employeeId) => {
  const res = await api.post('/login', { employee_id: employeeId });
  if (res.data.access_token) {
    localStorage.setItem('access_token', res.data.access_token);
  }
  return res.data;
};

export const logout = () => {
  localStorage.removeItem('access_token');
};

export const getProfile = async () => {
  const res = await api.get('/profile');
  return res.data;
};

export const uploadPayslip = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  const res = await api.post('/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' }
  });
  return res.data;
};

export const extractData = async (filename) => {
  const res = await api.post(`/extract?filename=${filename}`);
  return res.data;
};

export const getPayroll = async () => {
  const res = await api.get('/payroll');
  return res.data;
};

export const chatWithAi = async (prompt) => {
  const res = await api.post('/chat', { prompt, has_pdf: false, has_image: false });
  return res.data;
};

export const simulateTax = async (data) => {
  const res = await api.post('/tax/simulate', data);
  return res.data;
};

export const getChecklist = async () => {
  const res = await api.get('/checklist');
  return res.data;
};

export default api;

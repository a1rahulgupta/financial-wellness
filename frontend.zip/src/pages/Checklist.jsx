import React, { useEffect, useState } from 'react';
import { Box, Typography, Paper, CircularProgress, List, ListItem, ListItemIcon, ListItemText, Chip } from '@mui/material';
import { Description, CheckCircle, PendingActions, Error as ErrorIcon } from '@mui/icons-material';
import { getChecklist } from '../services/api';

export default function Checklist() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getChecklist().then(data => {
      setItems(data.items);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return <Box display="flex" justifyContent="center" mt={10}><CircularProgress /></Box>;

  const getStatusColor = (status) => {
    if (status === 'Submitted') return 'success';
    if (status === 'Pending') return 'warning';
    return 'error';
  };

  const getStatusIcon = (status) => {
    if (status === 'Submitted') return <CheckCircle color="success" />;
    if (status === 'Pending') return <PendingActions color="warning" />;
    return <ErrorIcon color="error" />;
  };

  return (
    <Box maxWidth={600}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Investment Proof Checklist</Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>
        Ensure all your tax saving proofs are submitted before the financial year end.
      </Typography>

      <Paper elevation={1} sx={{ borderRadius: 2 }}>
        <List sx={{ p: 0 }}>
          {items.map((item, index) => (
            <ListItem 
              key={item.name} 
              sx={{ 
                p: 3, 
                borderBottom: index < items.length - 1 ? '1px solid rgba(0,0,0,0.08)' : 'none' 
              }}
            >
              <ListItemIcon>
                <Description fontSize="large" color="action" />
              </ListItemIcon>
              <ListItemText 
                primary={<Typography variant="h6">{item.name}</Typography>} 
              />
              <Box display="flex" alignItems="center" gap={1}>
                {getStatusIcon(item.status)}
                <Chip 
                  label={item.status} 
                  color={getStatusColor(item.status)} 
                  variant="outlined" 
                  size="small" 
                  sx={{ fontWeight: 'bold' }}
                />
              </Box>
            </ListItem>
          ))}
        </List>
      </Paper>
    </Box>
  );
}

import React from 'react';
import { Box, Typography, Paper, Grid, Avatar } from '@mui/material';
import { useAuth } from '../context/AuthContext';

export default function Profile() {
  const { user } = useAuth();

  if (!user) return null;

  const InfoField = ({ label, value }) => (
    <Box mb={2}>
      <Typography variant="caption" color="text.secondary" fontWeight="bold">{label}</Typography>
      <Typography variant="body1">{value}</Typography>
    </Box>
  );

  return (
    <Box maxWidth={800}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Employee Profile</Typography>
      
      <Paper elevation={1} sx={{ p: 4, borderRadius: 2, mt: 4 }}>
        <Box display="flex" alignItems="center" gap={3} mb={5}>
          <Avatar sx={{ width: 80, height: 80, bgcolor: 'primary.main', fontSize: 32 }}>
            {user.name.charAt(0)}
          </Avatar>
          <Box>
            <Typography variant="h5" fontWeight="bold">{user.name}</Typography>
            <Typography variant="body1" color="text.secondary">{user.designation}</Typography>
          </Box>
        </Box>
        
        <Grid container spacing={4}>
          <Grid item xs={12} sm={6}>
            <InfoField label="Employee ID" value={user.id} />
            <InfoField label="Email Address" value={user.email} />
            <InfoField label="Department" value={user.department} />
          </Grid>
          <Grid item xs={12} sm={6}>
            <InfoField label="PAN Number" value={user.pan} />
            <InfoField label="Date of Joining" value={user.doj} />
          </Grid>
        </Grid>
      </Paper>
    </Box>
  );
}

import React, { useEffect, useState } from 'react';
import { Typography, Box, Paper, CircularProgress, Table, TableBody, TableCell, TableContainer, TableHead, TableRow } from '@mui/material';
import { getPayroll } from '../services/api';

export default function Payroll() {
  const [payroll, setPayroll] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getPayroll().then(data => {
      setPayroll(data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return <Box display="flex" justifyContent="center" mt={10}><CircularProgress /></Box>;
  if (!payroll) return <Typography mt={5}>No payroll data available. Please upload a payslip.</Typography>;

  const current = payroll.current_month;

  const createRow = (label, value) => (
    <TableRow key={label}>
      <TableCell component="th" scope="row">{label}</TableCell>
      <TableCell align="right">₹ {value.toLocaleString()}</TableCell>
    </TableRow>
  );

  return (
    <Box maxWidth={800}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Payroll Records</Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>Detailed breakdown for {current.month} {current.year}</Typography>

      <TableContainer component={Paper} elevation={1} sx={{ borderRadius: 2 }}>
        <Table>
          <TableHead sx={{ bgcolor: 'action.hover' }}>
            <TableRow>
              <TableCell><Typography fontWeight="bold">Component</Typography></TableCell>
              <TableCell align="right"><Typography fontWeight="bold">Amount (INR)</Typography></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {createRow('Basic Salary', current.basic_salary)}
            {createRow('House Rent Allowance (HRA)', current.hra)}
            {createRow('Leave Travel Allowance (LTA)', current.lta)}
            {createRow('Special Allowance', current.special_allowance)}
            {createRow('Reimbursements', current.reimbursement)}
            <TableRow><TableCell colSpan={2}></TableCell></TableRow>
            <TableRow sx={{ bgcolor: 'success.light' }}>
              <TableCell><Typography fontWeight="bold">Gross Pay</Typography></TableCell>
              <TableCell align="right"><Typography fontWeight="bold">₹ {current.gross_pay.toLocaleString()}</Typography></TableCell>
            </TableRow>
            <TableRow><TableCell colSpan={2}></TableCell></TableRow>
            {createRow('Provident Fund (PF)', current.pf)}
            {createRow('Professional Tax', current.professional_tax)}
            {createRow('Income Tax', current.income_tax)}
            <TableRow><TableCell colSpan={2}></TableCell></TableRow>
            <TableRow sx={{ bgcolor: 'primary.light' }}>
              <TableCell><Typography fontWeight="bold" color="primary.dark">Net Pay</Typography></TableCell>
              <TableCell align="right"><Typography fontWeight="bold" color="primary.dark">₹ {current.net_pay.toLocaleString()}</Typography></TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    </Box>
  );
}

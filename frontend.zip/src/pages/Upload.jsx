import React, { useState } from 'react';
import { Typography, Box, Paper, Button, Alert, CircularProgress } from '@mui/material';
import { CloudUpload } from '@mui/icons-material';
import { uploadPayslip, extractData } from '../services/api';

export default function Upload() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    setError('');
    setResult(null);
    try {
      const uploadRes = await uploadPayslip(file);
      const extractRes = await extractData(uploadRes.filename);
      setResult(extractRes);
    } catch (err) {
      setError('Failed to upload or extract data.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxWidth={600}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Upload Payslip</Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>
        Upload your monthly payslip (PDF, PNG, JPEG) to extract payroll data and enable AI assistance.
      </Typography>

      <Paper elevation={1} sx={{ p: 4, borderRadius: 2, textAlign: 'center', border: '2px dashed rgba(0,0,0,0.1)' }}>
        <CloudUpload sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
        <Typography variant="h6" gutterBottom>Drag & Drop or Select File</Typography>
        <input
          type="file"
          accept=".pdf,.png,.jpg,.jpeg"
          onChange={(e) => setFile(e.target.files[0])}
          style={{ display: 'none' }}
          id="file-upload"
        />
        <label htmlFor="file-upload">
          <Button variant="outlined" component="span" sx={{ mt: 2 }}>
            Choose File
          </Button>
        </label>
        {file && <Typography mt={2} color="primary">{file.name}</Typography>}
        
        <Box mt={4}>
          <Button 
            variant="contained" 
            size="large" 
            onClick={handleUpload} 
            disabled={!file || loading}
            fullWidth
          >
            {loading ? <CircularProgress size={24} /> : 'Process Payslip'}
          </Button>
        </Box>
      </Paper>

      {error && <Alert severity="error" sx={{ mt: 3 }}>{error}</Alert>}
      
      {result && (
        <Alert severity="success" sx={{ mt: 3 }}>
          Extraction successful! Processed Net Pay: ₹{result.net_pay.toLocaleString()} for {result.month} {result.year}.
        </Alert>
      )}
    </Box>
  );
}

import React, { useEffect, useState } from 'react';
import { Typography, Grid, Paper, Box, CircularProgress } from '@mui/material';
import { getPayroll } from '../services/api';
import ChatWidget from '../components/ChatWidget';
import { AccountBalance, TrendingUp, Receipt, ReceiptLong } from '@mui/icons-material';

export default function Dashboard() {
  const [payroll, setPayroll] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getPayroll().then(data => {
      setPayroll(data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return <Box display="flex" justifyContent="center" mt={10}><CircularProgress /></Box>;
  if (!payroll) return <Typography mt={5}>No payroll data available. Please upload a payslip.</Typography>;

  const current = payroll.current_month;

  const StatCard = ({ title, value, icon, color }) => (
    <Paper elevation={1} sx={{ p: 3, display: 'flex', alignItems: 'center', gap: 3, borderRadius: 2 }}>
      <Box sx={{ p: 2, borderRadius: '50%', bgcolor: `${color}.light`, color: `${color}.main`, display: 'flex' }}>
        {icon}
      </Box>
      <Box>
        <Typography variant="body2" color="text.secondary" fontWeight="bold">{title}</Typography>
        <Typography variant="h5" fontWeight="bold">₹ {value.toLocaleString()}</Typography>
      </Box>
    </Paper>
  );

  return (
    <Box>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Dashboard</Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>
        Overview for {current.month} {current.year}
      </Typography>

      <Grid container spacing={3}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Net Salary" value={current.net_pay} icon={<AccountBalance fontSize="large" />} color="primary" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Gross Salary" value={current.gross_pay} icon={<TrendingUp fontSize="large" />} color="secondary" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="Income Tax" value={current.income_tax} icon={<Receipt fontSize="large" />} color="error" />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard title="PF Deduction" value={current.pf} icon={<ReceiptLong fontSize="large" />} color="warning" />
        </Grid>
      </Grid>
      <ChatWidget />
    </Box>
  );
}

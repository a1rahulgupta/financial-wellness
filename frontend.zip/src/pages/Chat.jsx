import React, { useState } from 'react';
import { Box, Typography, Paper, TextField, Button, CircularProgress } from '@mui/material';
import { Send, SmartToy } from '@mui/icons-material';
import { chatWithAi } from '../services/api';

export default function Chat() {
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState([
    { role: 'ai', text: 'Hello! I have access to your uploaded payslips and profile. Ask me anything about your compensation, deductions, or taxes.' }
  ]);
  const [loading, setLoading] = useState(false);

  const handleSend = async () => {
    if (!prompt.trim()) return;
    const userMsg = prompt;
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setPrompt('');
    setLoading(true);
    
    try {
      const res = await chatWithAi(userMsg);
      setMessages(prev => [...prev, { role: 'ai', text: res.response }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'ai', text: 'Sorry, I am having trouble answering right now.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box sx={{ height: 'calc(100vh - 120px)', display: 'flex', flexDirection: 'column', maxWidth: 800, margin: '0 auto' }}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>AI Assistant</Typography>
      
      <Paper elevation={1} sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column', borderRadius: 2, overflow: 'hidden' }}>
        <Box sx={{ p: 2, bgcolor: 'primary.main', color: 'white', display: 'flex', alignItems: 'center', gap: 2 }}>
          <SmartToy />
          <Typography variant="h6">Grounded AI Chat</Typography>
        </Box>
        
        <Box sx={{ flexGrow: 1, p: 3, overflowY: 'auto', bgcolor: 'background.default', display: 'flex', flexDirection: 'column', gap: 2 }}>
          {messages.map((msg, i) => (
            <Box key={i} sx={{ alignSelf: msg.role === 'user' ? 'flex-end' : 'flex-start', maxWidth: '75%' }}>
              <Paper elevation={1} sx={{ p: 2, bgcolor: msg.role === 'user' ? 'primary.main' : 'white', color: msg.role === 'user' ? 'white' : 'text.primary', borderRadius: 2 }}>
                <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap' }}>{msg.text}</Typography>
              </Paper>
            </Box>
          ))}
          {loading && <CircularProgress size={30} sx={{ alignSelf: 'center', mt: 2 }} />}
        </Box>
        
        <Box sx={{ p: 2, bgcolor: 'white', display: 'flex', gap: 2, borderTop: '1px solid rgba(0,0,0,0.1)' }}>
          <TextField 
            fullWidth variant="outlined" placeholder="Ask about HRA, taxes, or PF..." 
            value={prompt} onChange={e => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
          />
          <Button variant="contained" color="primary" onClick={handleSend} disabled={loading || !prompt.trim()} sx={{ px: 4 }}>
            <Send />
          </Button>
        </Box>
      </Paper>
    </Box>
  );
}

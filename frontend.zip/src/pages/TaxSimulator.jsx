import React, { useState } from 'react';
import { Box, Typography, Paper, TextField, Button, Grid, CircularProgress, Alert } from '@mui/material';
import { simulateTax } from '../services/api';

export default function TaxSimulator() {
  const [formData, setFormData] = useState({
    current_taxable_income: 1200000,
    current_deductions: 50000,
    additional_80c_investment: 0
  });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSimulate = async () => {
    setLoading(true);
    try {
      const res = await simulateTax(formData);
      setResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxWidth={800}>
      <Typography variant="h4" fontWeight="bold" gutterBottom>Tax Simulator</Typography>
      <Typography variant="body1" color="text.secondary" mb={4}>
        Simulate tax savings by declaring additional investments (e.g. 80C).
      </Typography>

      <Grid container spacing={4}>
        <Grid item xs={12} md={6}>
          <Paper elevation={1} sx={{ p: 4, borderRadius: 2 }}>
            <Typography variant="h6" mb={3} fontWeight="bold">Input Parameters</Typography>
            <TextField 
              fullWidth label="Current Taxable Income" type="number" 
              value={formData.current_taxable_income}
              onChange={(e) => setFormData({...formData, current_taxable_income: Number(e.target.value)})}
              sx={{ mb: 3 }}
            />
            <TextField 
              fullWidth label="Current Deductions" type="number" 
              value={formData.current_deductions}
              onChange={(e) => setFormData({...formData, current_deductions: Number(e.target.value)})}
              sx={{ mb: 3 }}
            />
            <TextField 
              fullWidth label="Additional 80C Investment" type="number" 
              value={formData.additional_80c_investment}
              onChange={(e) => setFormData({...formData, additional_80c_investment: Number(e.target.value)})}
              sx={{ mb: 4 }}
              helperText="Max 1.5 Lakhs allowed under section 80C"
            />
            <Button variant="contained" fullWidth size="large" onClick={handleSimulate} disabled={loading}>
              {loading ? <CircularProgress size={24} /> : 'Simulate Tax'}
            </Button>
          </Paper>
        </Grid>

        <Grid item xs={12} md={6}>
          {result && (
            <Paper elevation={1} sx={{ p: 4, borderRadius: 2, bgcolor: 'primary.light', color: 'primary.dark' }}>
              <Typography variant="h6" mb={3} fontWeight="bold">Simulation Results</Typography>
              
              <Box mb={3}>
                <Typography variant="body2" fontWeight="bold">Estimated Taxable Income</Typography>
                <Typography variant="h4">₹ {result.estimated_taxable_income.toLocaleString()}</Typography>
              </Box>
              
              <Box mb={4}>
                <Typography variant="body2" fontWeight="bold">Estimated Tax Saved</Typography>
                <Typography variant="h4" color="success.main">₹ {result.estimated_tax_saved.toLocaleString()}</Typography>
              </Box>
              
              <Alert severity="info" sx={{ mt: 2 }}>
                <Typography variant="caption" fontWeight="bold">Assumptions:</Typography>
                <ul style={{ margin: 0, paddingLeft: '20px' }}>
                  {result.assumptions.map((assump, i) => <li key={i}><Typography variant="caption">{assump}</Typography></li>)}
                </ul>
              </Alert>
            </Paper>
          )}
        </Grid>
      </Grid>
    </Box>
  );
}
